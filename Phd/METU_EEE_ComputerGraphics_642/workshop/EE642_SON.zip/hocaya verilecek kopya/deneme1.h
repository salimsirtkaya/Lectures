//---------------------------------------------------------------------------
#ifndef deneme1H
#define deneme1H
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
#include <vcl\Menus.hpp>
#include <vcl\Tabnotbk.hpp>
#include <vcl\ComCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TPaintBox *PaintBox1;
	TPanel *Panel2;
	TRadioButton *RadioButton1;
	TRadioButton *RadioButton2;
	TEdit *X1;
	TEdit *Y1;
	TEdit *Y2;
	TEdit *Z1;
	TEdit *Z2;
	TEdit *Edit1;
	TEdit *X2;
	TPanel *Panel3;
	TButton *Point_properties;
	TComboBox *Point_properties_size;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *des_label1;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TLabel *Label6;
	TButton *OK;
	TMainMenu *MainMenu1;


	TMenuItem *Options1;
	
	TButton *Transformation;
	TPanel *Panel4;
	TButton *Translation;
	TButton *Rotation;
	TComboBox *LineProperties;
	TPanel *Panel5;
	TLabel *labeldegree;
	TButton *Box;
	TButton *perspective;
	TPanel *Panel6;
	TPanel *Panel7;
	TEdit *Edit3;
	TEdit *Edit4;
	TEdit *Edit5;
	TPanel *Panel8;
	TPanel *Panel9;
	TPanel *Panel10;
	TButton *Apply;
	TButton *Curves;
	TPanel *Panel11;
	TPanel *Panel12;
	TButton *Button1;
	TButton *Button2;
	TPanel *Panel13;
	TEdit *Edit6;
	TEdit *Edit7;
	TEdit *Edit8;
	TLabel *Label7;
	TLabel *Label8;
	TLabel *Label9;
	TButton *Draw;
	TLabel *Label10;
	TEdit *Edit9;
	TButton *hyperbola;
	TButton *parabola;
	TLabel *Label11;
	TPanel *Panel14;
	TEdit *Edit10;
	TEdit *Edit11;
	TButton *Splines;
	TPanel *Panel15;
	TButton *Button3;
	TButton *CubicSpline;
	TButton *EndSpline;
	TPanel *Panel16;
	TLabel *Label12;
	TLabel *Label13;
	TLabel *Label14;
	TButton *Button4;

	TButton *ParaBlend;
	TButton *cyclicend;
	TButton *anticyclic;
	TButton *Select;
	TPanel *Panel17;
	TButton *Button5;

	TLabel *Label16;
	TLabel *Label17;


	TPanel *Panel20;
	TEdit *Edit13;
	TButton *Button13;
	TLabel *Label20;
	TMenuItem *RotationAngles1;
	TButton *Button15;
	TPanel *Panel22;
	TButton *Button16;
	TButton *Button17;
	TButton *Button18;
	TButton *Button19;
	TButton *Button20;
	TMenuItem *SurfaceLines1;
	TPanel *Panel23;
	TEdit *Edit16;
	TButton *Button21;
	TLabel *Label23;
	TButton *Button22;
	TPanel *Panel24;
	TButton *Button23;

	TEdit *Edit17;
	TLabel *Label24;
TButton *Button29;
	TButton *aroundx;
	TButton *aroundy;
	TButton *aroundz;
	TButton *OKrotate;
	TEdit *degree;
	TButton *Bezier;
	TButton *Button8;
        TPanel *Panel25;
        TPanel *Panel26;
        TPanel *Panel27;
        TPanel *Panel28;
        
void __fastcall RadioButton1Click(TObject *Sender);
	void __fastcall RadioButton2Click(TObject *Sender);
	void __fastcall PaintBox1MouseMove(TObject *Sender, TShiftState Shift, int X,
	int Y);
	

	


	void __fastcall Point_propertiesClick(TObject *Sender);
	void __fastcall OKClick(TObject *Sender);
	void __fastcall Point_properties_sizeChange(TObject *Sender);
	
	void __fastcall PaintBox1MouseDown(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y);
	void __fastcall PaintBox1MouseUp(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y);

	
	void __fastcall Erase1Click(TObject *Sender);
void __fastcall On1Click(TObject *Sender);
	void __fastcall Off1Click(TObject *Sender);
	void __fastcall TransformationClick(TObject *Sender);
	void __fastcall TranslationClick(TObject *Sender);
	void __fastcall RotationClick(TObject *Sender);

	void __fastcall LinePropertiesChange(TObject *Sender);
	
	
	void __fastcall aroundxClick(TObject *Sender);
	void __fastcall aroundyClick(TObject *Sender);
	void __fastcall aroundzClick(TObject *Sender);
	
	
	void __fastcall OKrotateClick(TObject *Sender);
	void __fastcall BoxClick(TObject *Sender);
	void __fastcall perspectiveClick(TObject *Sender);
	void __fastcall ApplyClick(TObject *Sender);
	
	
	void __fastcall CurvesClick(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall DrawClick(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall hyperbolaClick(TObject *Sender);
	void __fastcall parabolaClick(TObject *Sender);
	
	
	void __fastcall Panel12Click(TObject *Sender);
	
	
	void __fastcall Color1Click(TObject *Sender);
	void __fastcall CubicSplineClick(TObject *Sender);
	void __fastcall EndSplineClick(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall SplinesClick(TObject *Sender);
	
	void __fastcall Button4Click(TObject *Sender);

	void __fastcall ParaBlendClick(TObject *Sender);
	void __fastcall cyclicendClick(TObject *Sender);
	void __fastcall anticyclicClick(TObject *Sender);
	void __fastcall SelectClick(TObject *Sender);
	void __fastcall ListBox1Click(TObject *Sender);
	void __fastcall BezierClick(TObject *Sender);
void __fastcall Button5Click(TObject *Sender);
void __fastcall Button8Click(TObject *Sender);
void __fastcall Button13Click(TObject *Sender);

	void __fastcall Button15Click(TObject *Sender);
	void __fastcall Button16Click(TObject *Sender);
	void __fastcall Button17Click(TObject *Sender);
	void __fastcall Button18Click(TObject *Sender);
	void __fastcall Button19Click(TObject *Sender);
	void __fastcall Button20Click(TObject *Sender);
	void __fastcall Button21Click(TObject *Sender);
	void __fastcall SurfaceLines1Click(TObject *Sender);
	
	void __fastcall Button22Click(TObject *Sender);
void __fastcall Button23Click(TObject *Sender);
void __fastcall Button29Click(TObject *Sender);
   





private:
public:		//
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
