//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "matrix.h"
//--------------------------------------------------------------------
double dot_product(double a1=0,double a2=0,double a3=0,double b1=0,double b2=0,double b3=0)
{
 return (a1*b1+a2*b2+a3*b3);

}