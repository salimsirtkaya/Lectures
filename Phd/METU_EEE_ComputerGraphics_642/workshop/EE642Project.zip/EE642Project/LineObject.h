#pragma once
#include "compgraphobject.h"

