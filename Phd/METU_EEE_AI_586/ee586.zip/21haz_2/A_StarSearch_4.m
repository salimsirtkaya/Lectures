function Partial_Plan = A_StarSearch(maze, row, col, block_size, maze_size)

objects = kiks_siminfo_objects;
[obj,prop] = size(objects);
for i=1:obj
    if(objects(i,1)==0)
        goal_pos = objects(i,2:3)
    end
end

%%manip-search yaparken maze in ortalarinda bi yerlerde cagirilacak
%%dist_to_goal = sqrt(square(pos(1)-goal_pos(1)) + square(pos(2)-goal_pos(2)));
%%en basta cagirilacak (0,0)

pos= [75-33; 75-33];
dist_to_goal = sqrt((pos(1)-goal_pos(1))^2 + (pos(2) - goal_pos(2))^2);

%%%%transform into matrix indexes%%%%%%%%
matrix_row = maze_size;
matrix_col= maze_size + 2;

moves = zeros(matrix_row,matrix_row);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%daha once gecilen yerlerden gecmemek icin kullanilacak
history_stack = zeros(matrix_row,matrix_col);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%hedefe ulastiktan sonra dead-end olan yerlerden gecmemek icin kullanilacak
%%gelinen pozisyon check edilcek eger dead-end e karsilik geliyosa orasi path e eklenmeyecek..
dead_end = zeros(matrix_row,matrix_col);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pos_col = 1;%%1-matrix_col arasinda 
pos_row= 1;%%1-matrix_row arasinda 

% stack = [pos_row pos_col];

heur_stack = [pos_row pos_col];
Partial_Plan = [];
State = [];
offset = 60;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                  start loop                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
goalx = ceil(goal_pos(1)/120);
goaly = ceil(goal_pos(2)/120);
goal_loc = [goaly goalx];
cur_pos = [pos_row pos_col];
while goalx~=pos_col | goaly ~= pos_row%(dist_to_goal>50) % stop when robot gets near the light
    cnt = 0;%controls if search come to dead end..loop un icinde olmali devamli update edilmeli her state icin check edilmesi icin
%     [stack_size_row, stack_size_col] = size(stack);
%     %%%%%%%%%%%%%%pop_stack: en tepedekini al%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%     pos_row = stack(1);%%bunlari heuristic_stack ten cikart stack yerine
%     pos_col = stack(stack_size_row + 1);
%     
%     pos_index = (pos_col-1)*maze_size + pos_row;
%     stack(1,:) = [];%%stackten cikardigin state'i sil..yani en tepedekini
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %           sort heur_stack ve get pos_index value:                        %
    srtmat = heur_stack(:,2);
    [x i] = sort (srtmat);
    pos_index = heur_stack(i(1));
    heur_stack(i(1),:) = [];%%stackten cikardigin state'i sil..yani en tepedekini
    %%%%%%%%%%%%%%%%%%%%%%%pos_col ve pos_row leri pos_index ten elde et:%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if mod(pos_index,maze_size) == 0
        pos_row = maze_size;
    else
        pos_row = mod(pos_index,maze_size);
    end%if
        pos_col = ceil(pos_index/maze_size);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % robotun maze icinde olmasi gereken gercek pozisyonu: posy&posx
    posy = (pos_row-1) * block_size + offset;
    posx = ((pos_col-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60
    
    %%posy & posx maze dimensionlari veriyor   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %                                  legal moves                                %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%west%%
    if pos_col ~= 1
        %%%%%%%%%%search_area nin matrix boyutunu geciyor mu? kontrol et--sinirlari kontrol et!!!%%%%%%%%%%%%%%%%
        trans_matrix = maze(posy, posx - block_size : posx ); %%bu matrix icinde 1 yoksa gecis yapilabilir..
        if sum(sum(trans_matrix))==0 & pos_col~=1 & history_stack(pos_row, pos_col-1)~=1%%find if there is obstacle -sum(sum(search_area))==0 
            %%%going in west direction is legal!!
            moves(pos_row,pos_col-1) = 1; 
            %%vertically concatenate the position to the stack matrix(pozisyonu en tepeye yerlestir)
%             stack = [pos_row pos_col-1; stack] ;
            previous((pos_col-1-1)*maze_size + pos_row) = pos_index; 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%Calculate heuristic value of the cell:%% hedefe olan uzaklik
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % robotun maze icinde west yonunde giderse olacagi pozisyon pozisyonu: posyw & posxw
            posyw = (pos_row-1) * block_size + offset;
            posxw = ((pos_col-1-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60
            cur_pos = (pos_col-1-1)*maze_size + pos_row;
            distance_to_path = backtrack(previous,cur_pos);
            dist_to_goal = sqrt(((posxw) - goal_pos(1))^2 + (posyw  - goal_pos(2))^2);
            heuristic(cur_pos) = dist_to_goal + distance_to_path * 120 ;
            %current position icin her direction da heuristic degerini ata buna gore bi sonraki state e gec:
            heur(pos_index, 4) = dist_to_goal;
            heur_stack = [pos_index-maze_size heuristic(cur_pos) ;heur_stack];
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            cnt = cnt  + 1;
        end
    end  
    %%north%%
    if pos_row ~=1
        trans_matrix = maze(posy - block_size:posy , posx);
        if sum(sum(trans_matrix))==0 & pos_row~=0 & history_stack(pos_row - 1, pos_col)~=1%%find if there is obstacle -sum(sum(search_area))==0 
            %%%going in west direction is legal!!
            moves(pos_row - 1,pos_col) = 1; 
            %%vertically concatenate the position to the stack matrix(pozisyonu en tepeye yerlestir)
%             stack = [ pos_row-1 pos_col; stack] ;
            previous((pos_col-1)*maze_size + pos_row-1) = pos_index;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%Calculate heuristic value of the cell:%%hedefe olan uzaklik
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % robotun maze icinde west yonunde giderse olacagi pozisyon pozisyonu: posyw & posxw
            posyn = (pos_row-1-1) * block_size + offset;
            posxn = ((pos_col-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60
            cur_pos = (pos_col-1)*maze_size + pos_row-1;
            distance_to_path = backtrack(previous,cur_pos);
            dist_to_goal = sqrt(((posxn) - goal_pos(1))^2 + (posyn  - goal_pos(2))^2);
            heuristic(cur_pos) = dist_to_goal + distance_to_path * 120;
            heur(pos_index, 3) = dist_to_goal;
            heur_stack = [pos_index-1 heuristic(cur_pos) ; heur_stack];
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            cnt = cnt  + 1;      
        end
    end
       %%south%%
    if pos_row ~= matrix_row
        
        trans_matrix = maze(posy :posy + block_size, posx: posx );
        if sum(sum(trans_matrix))==0 & matrix_row~=0 & history_stack(pos_row + 1, pos_col)~=1%%find if there is obstacle- sum(sum(search_area))==0 
            moves(pos_row + 1,pos_col) = 1;
            %%vertically concatenate the position to the stack matrix(pozisyonu en tepeye yerlestir)
%             stack = [ pos_row + 1 pos_col; stack] ;
            previous((pos_col-1)*maze_size + pos_row+1) = pos_index;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%Calculate heuristic value of the cell:%% hedefe olan uzaklik
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % robotun maze icinde west yonunde giderse olacagi pozisyon pozisyonu: posyw & posxw
            posys = (pos_row+1-1) * block_size + offset;
            posxs = ((pos_col-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60
            cur_pos = (pos_col-1)*maze_size + pos_row+1;
            distance_to_path = backtrack(previous,cur_pos);
            dist_to_goal = sqrt(((posxs) - goal_pos(1))^2 + (posys  - goal_pos(2))^2);
            heuristic(cur_pos) = dist_to_goal + distance_to_path * 120;
            heur(pos_index, 2) = dist_to_goal;
            heur_stack = [pos_index+1 heuristic(cur_pos); heur_stack];%%heuristic matrise ekle 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            cnt = cnt  + 1;
        end
    end
    %%east%%
    if pos_col ~= matrix_col
        trans_matrix = maze(posy, posx : posx + block_size);
        if sum(sum(trans_matrix))==0 & pos_col~= matrix_col & history_stack(pos_row, pos_col + 1)~=1%%find if there is obstacle -sum(sum(search_area))==0 
            %%%set going in west direction is legal if no obstacle!!
            moves(pos_row,pos_col+1)= 1; 
            %%vertically concatenate the position to the stack matrix(pozisyonu en tepeye yerlestir)
%             stack = [ pos_row pos_col+1; stack] ;
            previous((pos_col+1-1)*maze_size + pos_row) = pos_index;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%Calculate heuristic value of the cell:%% hedefe olan uzaklik
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % robotun maze icinde west yonunde giderse olacagi pozisyon pozisyonu: posyw & posxw
            posye = (pos_row-1) * block_size + offset;
            posxe = ((pos_col+1-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60
            cur_pos = (pos_col+1-1)*maze_size + pos_row;
            distance_to_path = backtrack(previous,cur_pos);
            dist_to_goal = sqrt(((posxe) - goal_pos(1))^2 + (posye  - goal_pos(2))^2);
            heuristic(cur_pos) = dist_to_goal + distance_to_path * 120;
            heur(pos_index, 1) = dist_to_goal;
            heur_stack = [pos_index+maze_size heuristic(cur_pos); heur_stack];
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            cnt = cnt  + 1;
        end
    end
 
    
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%  hedefe olan uzakligi kontrol et%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dist_to_goal = sqrt(((posx) -goal_pos(1))^2 + (posy  - goal_pos(2))^2);
cur_pos = [pos_row pos_col];
if cur_pos == goal_loc%(dist_to_goal <60)
    fprintf('search path found: row%d col:%d', pos_row, pos_col);
    break;
end
history_stack(pos_row, pos_col) = 1;%%eger bu row ilerlediyse history'e at daha sonra check et 
end%while
% %%%%%%%%%%%%%%%Partial Plan i dondur: previous method ile%%%%%%%%%%%%%%%%%%
goalx = ceil(goal_pos(1)/120);
goaly = ceil(goal_pos(2)/120);
goal = goalx*goaly;
curs = goal;
Partial_Plan = [goaly goalx; Partial_Plan];
while curs ~= 1
    temp_curs = previous(curs);
    if mod(temp_curs,maze_size) == 0
        pre_row = maze_size;
    else
        pre_row = mod(temp_curs,maze_size);
    end%if
    pre_col = ceil(temp_curs/maze_size);
    Partial_Plan = [pre_row pre_col; Partial_Plan];
    curs = temp_curs;
end

%%calculates distance to start in square values
function distance_to_path = backtrack(prev_mat,cur_pos)
curs = cur_pos;
distance_to_path = 0;
while curs ~= 1
    temp_curs = prev_mat(curs);
    curs = temp_curs;
    distance_to_path = distance_to_path + 1;
end