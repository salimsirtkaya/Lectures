%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%   Current pozisyonun Heuristic degerlerini ata..sonra sort et  bu siralamaya 
    %%   gore bi sonraki state e gec%
    %%   heur(q,y) matrisinde q current deger (1 ile maze_size*maze_size arasi), 
    %%   y ise sira ile:
    %%    1-> east
    %%    2-> south 
    %%    3-> north
    %%    4-> west
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    [Y,I] = sort (heur(pos_index);%%%cikan index sonucuna gore bi sonraki degere gec
    for j = 1:cnt
        if I(j) == 1 % east
            next_index(j) = pos_index + maze_size ;
            next_index(j+) = pos_index + maze_size ;
                heur(pos_index, 1) = inf;    
            elseif I(1) == 2 % south
                next_index(1:2) = pos_index + 1
                heur(pos_index, 2) = inf;
            elseif I(1) == 3 % north
                next_index(1:2) = pos_index -1;
                heur(pos_index, 3) = inf;
            elseif I(1) == 4 % west
                next_index(1:2) = pos_index - maze_size;
                heur(pos_index, 4) = inf;
         end
    end
    
    if I(2) == 1 % east
        next_index(2) = pos_index + maze_size;
        
    elseif I(2) == 2 % south
        next_index(2) = pos_index + 1
    elseif I(2) == 3 % north
        next_index(1) = pos_index -1;   
    elseif I(2) == 4 % west
        next_index(1) = pos_index - maze_size;
    end
    
    if I(3) == 1 % east
        next_index(3) = pos_index + maze_size;
        
    elseif I(3) == 2 % south
        next_index(3) = pos_index + 1
    elseif I(3) == 3 % north
        next_index(3) = pos_index -1;   
    elseif I(3) == 4 % west
        next_index(3) = pos_index - maze_size;
    end
    
    if I(4) == 1 % east
        next_index(4) = pos_index + maze_size;
        heur(pos_index, 1) = 
    elseif I(4) == 2 % south
        next_index(4) = pos_index + 1
    elseif I(4) == 3 % north
        next_index(4) = pos_index -1;   
    elseif I(4) == 4 % west
        next_index(4) = pos_index - maze_size;
    end
    
    
    if mod(next_pos,maze_size) == 0
        next_row = maze_size;
    else
        next_row = mod(next_pos,maze_size);
    end%if
    next_col = ceil(temp_curs/maze_size);
    heur(I(1)) = -1;%%heuristigi en dusuk olan statei
    heuristic_stack = [next_row next_col; heuristic_stack]