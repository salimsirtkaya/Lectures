% -----------------------------------------------------
%  �zkan G�NDER
%  EE586-2005  Term Project
%  Instructor: Afsar Saranli
%V.3-> ilerleme blok boyutunu 75 den 110 ya da 120 ye cikardim...
% -----------------------------------------------------
 function maze(port,baud,maze_size)

% maze(port,baud)
% port = serial port to communicate with (port<0 ==> simulated robot, port>=0 ==> real robot
% baud = baud rate
% maze_size = size of maze

if(nargin<3) maze_size=4; end;
if(nargin<2) baud=9600; end;
if(nargin<1) port=-1; end;

if port<0 % only if this is a simulated robot
    a = kiks_generate_maze(maze_size,maze_size); 
   kiks_arena(a); % set up a new arena using the kiks_generate_maze function
end;

% for i=1:2, 
%     kiks_spawn(i+1); %%1-kucuk kure 2-buyuk 3-isik
% end
%%% size of the maze matrix %%%%
[row,col] = size(a);
pos = [col,row];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% place the object randomly %%

% kiks_spawn(1,pos);

% kiks_siminfo_robotpos
% kiks_siminfo_objects
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf(' size of maze- row: %f col: %f \n',row, col);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
objects = kiks_siminfo_objects;
[obj,prop] = size(objects);
for i=1:obj
  if(objects(i,1)==0)
    goal_pos = objects(i,2:3);
  end
end

block_size = 120;%%maze icinde search edecek block boyutu..
search_area =  a(1:block_size,1:block_size);
pos = [75-33; 75-33];
offset = 60;
% kiks_arena_edit;
% 
% pause;

%  for i=1:2, 
%      kiks_spawn(i+1); %%1-kucuk kure 2-buyuk 3-isik
%  end
% pause;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%                      Start_A* Search                            %%%%%%%%%%%%%%%%
Partial_Plan = A_StarSearch(a, row, col, block_size, maze_size)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%                         Draw Path                                %%%%%%%%%%%%%%%
temp_plan = Partial_Plan;
[temp_plan_size_row, temp_plan_size_col] = size(temp_plan);
kiks_siminfo_setrobot( 55.0000,   60.0000,    6.2832);%set robot tostart pos..
for i=1:temp_plan_size_row
  [temp_plan_size_row, temp_plan_size_col] = size(temp_plan);
  pos_row = temp_plan(1);
  pos_col = temp_plan(temp_plan_size_row + 1);
  temp_plan(1,:) = [];%%stackten cikardigin state'i sil..yani en tepedekini
  % robotun maze icinde olmasi gereken gercek pozisyonu: posy&posx
  posy = (pos_row-1) * block_size + offset;
  posx = ((pos_col-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60
 %kiks_siminfo_setrobot(posx ,posy);
 %%%%%%%%%%partial plan i ciz:%%%%%%%%%%%%%%%%%%%
 [temp_plan_size_row, temp_plan_size_col] = size(temp_plan);
 if temp_plan_size_row ~=0
  [temp_plan_size_row, temp_plan_size_col] = size(temp_plan);
  temp_row = temp_plan(1);
  temp_col = temp_plan(temp_plan_size_row + 1);
  tempy = (temp_row-1) * block_size + offset;
  tempx = ((temp_col-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60
  %%stackten cikardigin state'i sili sonraki stepte kullanilcak..
%   
%     fprintf(' posx: %f posy: %f  tempx: %f tempy: %f \n',posx, posy,  tempx ,tempy);
    if(tempx>=posx) & (tempy>=posy)
      plot( posx/2: tempx/2, posy/2:tempy/2,sprintf('%s.-','c'));
    elseif (tempx>=posx) & (posy>=tempy)
      plot( posx/2: tempx/2, tempy/2:posy/2,sprintf('%s.-','c'));
    elseif (tempx<=posx) & (posy>=tempy)
      plot(tempx/2:posx/2, tempy/2:posy/2,sprintf('%s.-','c'));
    elseif (tempx<=posx) & (tempy>=posy)
      plot(tempx/2:posx/2, posy/2:temp/2,sprintf('%s.-','c'));
    end%if
  end%if
end%for
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%                      Start Robot Motion                          %%%%%%%%%%%%%%%
ref=kiks_kopen([-1,baud,1]);
temp_plan = Partial_Plan;
temp_plan(1,:) = [];%%en tepedeki [1,1] oldugu icin robotun initial pozisyon die sildim
[temp_plan_size_row, temp_plan_size_col] = size(temp_plan);
kSetEncoders(ref,0,0);
for i=1:temp_plan_size_row
  [temp_plan_size_row, temp_plan_size_col] = size(temp_plan);
  temp_row = temp_plan(1);
  temp_col = temp_plan(temp_plan_size_row + 1);
  temp_plan(1,:) = [];%%stackten cikardigin state'i sil..yani en tepedekini
  tempy = (temp_row-1) * block_size + offset;
  tempx = ((temp_col-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60
  rob_pos = kiks_siminfo_robotpos;
  dist_to_target = sqrt((rob_pos(1)-tempx)^2 + (rob_pos(2) - tempy)^2);
  rob_col = ceil(rob_pos(1)/120);
  rob_row = ceil(rob_pos(2)/120);
  if(rob_col)< (temp_col)
      head = 2*pi;%pi*2
  elseif (rob_col)> (temp_col)
      head = pi;    
  elseif (rob_row)> (temp_row)
      head = pi/2;
  elseif (rob_row)< (temp_row)
      head = 3*pi/2;
  end
  kiks_siminfo_setrobot(rob_pos(1) ,rob_pos(2),head);%%robotu gidecegi yone dogru dondur..
  ref=kiks_kopen([-1,baud,1]);
  i = 4;
  while (dist_to_target >10) %i >0% stop when robot gets near the light
   % for calculating loops/second
   %ref=kiks_kopen([-1,baud,1]);
   speed = [1 1];
%    kSetSpeed(ref,speed(1),speed(2));   
%    mov_err = kGetStatus(ref);
%    backup(ref,[mov_err(3) mov_err(6)],speed);
%    kSetEncoders(ref,0,0);
%    if head == pi | head == 2*pi
%      x= 12 * (tempx-rob_pos(1));
%      kMoveTo(ref, x, x);
%    else
%      y = 12 * (tempy-rob_pos(2));
%      kMoveTo(ref, y, y);
%    end
   if head == pi | head == 2*pi
     x = tempx/i;
     i = i-1;
     y = rob_pos(2);
   else
     y = tempy/i;
     i = i-1;
     x = rob_pos(1);
   end
   
   kiks_siminfo_setrobot(tempx ,tempy,head);%%robotu gidecegi yone dogru dondur..
   rob_pos = kiks_siminfo_robotpos;
   
   if rob_col == maze_size-1
       tempx = tempx + 10;
   end
   if rob_row == maze_size
       tempy = tempy + 10;
   end
    dist_to_target = sqrt((rob_pos(1)-tempx)^2 + (rob_pos(2) - tempy)^2);
  end
  kiks_kclose(ref);%her for loop icinde bi daha kopen yap
end

  
n=1;%%debug icin ..sil sonra
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% while (dist_to_goal>55) % stop when robot gets near the light
%   
%     %%go east%%
%     R = go_east(posy, posx, a);%returns posy, posx and obstacle flag!!! 
%     %%%%%%%%%%navigasyon tasarimi devam ediyor..goal e  gelene kadar gecilen butun pathleri kaydetip arada engel varsa 
%     %% bu noktada manip-search tasarlamak gerekli!!
%    
%    reflex = kProximity(ref);
%   
%    dist_to_goal = sqrt(sqr(pos(1)-goal_pos(1)) + sqr(pos(2)-goal_pos(2)));
% end




function Partial_Plan = A_StarSearch(maze, row, col, block_size, maze_size)

objects = kiks_siminfo_objects;
[obj,prop] = size(objects);
for i=1:obj
  if(objects(i,1)==0)
    goal_pos = objects(i,2:3)
  end
end

%%manip-search yaparken maze in ortalarinda bi yerlerde cagirilacak
%%dist_to_goal = sqrt(square(pos(1)-goal_pos(1)) + square(pos(2)-goal_pos(2)));
%%en basta cagirilacak (0,0)
pos= [75-33; 75-33];
dist_to_goal = sqrt((pos(1)-goal_pos(1))^2 + (pos(2) - goal_pos(2))^2);

%%%%transform into matrix indexes%%%%%%%%
matrix_row = maze_size;
matrix_col= maze_size + 2;

moves = zeros(matrix_row,matrix_row);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%daha once gecilen yerlerden gecmemek icin kullanilacak
history_stack = zeros(matrix_row,matrix_col);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%hedefe ulastiktan sonra dead-end olan yerlerden gecmemek icin kullanilacak
%%gelinen pozisyon check edilcek eger dead-end e karsilik geliyosa orasi path e eklenmeyecek..
dead_end = zeros(matrix_row,matrix_col);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pos_col = 1;%%1-matrix_col arasinda 
pos_row= 1;%%1-matrix_row arasinda 

stack = [pos_row pos_col];
backtracking_stack = [];
Partial_Plan = [];
State = [];
offset = 60;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                  start loop                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while (dist_to_goal>50) % stop when robot gets near the light
cnt = 0;%controls if search come to dead end..loop un icinde olmali devamli update edilmeli her state icin check edilmesi icin
[stack_size_row, stack_size_col] = size(stack);
%%%%%%%%%%%%%%pop_stack: en tepedekini al%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
pos_row = stack(1);
pos_col = stack(stack_size_row + 1);
stack(1,:) = [];%%stackten cikardigin state'i sil..yani en tepedekini

% robotun maze icinde olmasi gereken gercek pozisyonu: posy&posx
posy = (pos_row-1) * block_size + offset;
posx = ((pos_col-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60

%%posy & posx maze dimensionlari veriyor   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                  legal moves                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%west%%
if pos_col ~= 1
   %%%%%%%%%%search_area nin matrix boyutunu geciyor mu? kontrol et--sinirlari kontrol et!!!%%%%%%%%%%%%%%%%
   trans_matrix = maze(posy, posx - block_size : posx ); %%bu matrix icinde 1 yoksa gecis yapilabilir..
   if sum(sum(trans_matrix))==0 & pos_col~=1 & history_stack(pos_row, pos_col-1)~=1%%find if there is obstacle -sum(sum(search_area))==0 
   %%%going in west direction is legal!!
   moves(pos_row,pos_col-1) = 1; 
   %%vertically concatenate the position to the stack matrix(pozisyonu en tepeye yerlestir)
   stack = [pos_row pos_col-1; stack] ;
   previous((pos_col-1-1)*maze_size + pos_row) = (pos_col-1)*maze_size + pos_row;
   cnt = cnt  + 1;
   end
end  
  %%north%%
if pos_row ~=1
   trans_matrix = maze(posy - block_size:posy , posx);
   if sum(sum(trans_matrix))==0 & pos_row~=0 & history_stack(pos_row - 1, pos_col)~=1%%find if there is obstacle -sum(sum(search_area))==0 
      %%%going in west direction is legal!!
      moves(pos_row - 1,pos_col) = 1; 
      %%vertically concatenate the position to the stack matrix(pozisyonu en tepeye yerlestir)
      stack = [ pos_row-1 pos_col; stack] ;
      previous((pos_col-1)*maze_size + pos_row-1) = (pos_col-1)*maze_size + pos_row;
      cnt = cnt  + 1;      
  end
end
  %%east%%
if pos_col ~= matrix_col
   trans_matrix = maze(posy, posx : posx + block_size);
   if sum(sum(trans_matrix))==0 & pos_col~= matrix_col & history_stack(pos_row, pos_col + 1)~=1%%find if there is obstacle -sum(sum(search_area))==0 
      %%%set going in west direction is legal if no obstacle!!
       moves(pos_row,pos_col+1)= 1; 
      %%vertically concatenate the position to the stack matrix(pozisyonu en tepeye yerlestir)
      stack = [ pos_row pos_col+1; stack] ;
      previous((pos_col+1-1)*maze_size + pos_row) = (pos_col-1)*maze_size + pos_row;
      cnt = cnt  + 1;
  end
end
  %%south%%
if pos_row ~= matrix_row

  trans_matrix = maze(posy :posy + block_size, posx: posx );
  if sum(sum(trans_matrix))==0 & matrix_row~=0 & history_stack(pos_row + 1, pos_col)~=1%%find if there is obstacle- sum(sum(search_area))==0 
      moves(pos_row + 1,pos_col) = 1;
      %%vertically concatenate the position to the stack matrix(pozisyonu en tepeye yerlestir)
      stack = [ pos_row + 1 pos_col; stack] ;
      previous((pos_col-1)*maze_size + pos_row+1) = (pos_col-1)*maze_size + pos_row;
      cnt = cnt  + 1;
  end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%            hic legal move yoksa dead end:         %%%%%%%%%%%%%%%%%%%%%%%
%  dist_to_goal = sqrt(((posx) -goal_pos(1))^2 + (posy  - goal_pos(2))^2);
%  
%   if cnt==0 & (dist_to_goal >60)%if [pos_row, pos_col] is not a dead state,
%      
%      dead_end(pos_row, pos_col) = 1; 
%      %dead-end e geldikten sonra bi onceki pozisyona gel ve state gelene kafar while loop ile ilerle
%      pre = previous((pos_col-1)*maze_size + pos_row);
%      if mod(pre,maze_size) == 0
%            pre_row = maze_size;
%        else
%            pre_row = mod(pre,maze_size);
%        end%if
%      pre_col = ceil(pre/maze_size);
%      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%      [state_size_row, state_size_col] = size(State);
%      state_row = -1;
%      state_col = -1;
%      while (state_row ~= pre_row) & (state_col ~= pre_col)%state row olana kadar ve state col olana kadar ilerle
%         for(i = 1:state_size_row)%her seferinde state matrisi kontrol et, geldiysek loop dan cik..
%         %gelmediysek 'pre' pozisyonu dead_end yap while loopa devam et..
%           state_row = State(i);
%           state_col = State(state_size_row + i);
%           state_cnt = State(state_size_row*2 + i);
%           if (state_row == pre_row) & (state_col == pre_col) & (state_row ~= maze_size) & (state_col ~= maze_size)
%               if state_cnt == 0  
%                 dead_end(state_row, state_col) = 1;%bununla ayni: dead_end(pre_row, pre_col) = 1;
%                
%               else
%                 state(state_size_row*2 + i) = cnt-1;   
%               end%if
%               break;%%state'e ulasildigi icin for loopdan cik!!!
%           end%if
%        end%for
%        if (state_row ~= pre_row) | (state_col ~= pre_col) 
%           dead_end(pre_row, pre_col) = 1;
%           pre = previous((pre_col-1)*maze_size + pre_row);
%           pre_col = ceil(pre/maze_size);
%           if mod(pre,maze_size) == 0
%              pre_row = maze_size;
%           else
%              pre_row = mod(pre,maze_size);
%           end%if mod(..
%        end%if (state_..
%      end%while
%   end%if
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  if cnt>1%eger gidecek directionsayisi 1 den fazlaysa bu nokta bi state'dir..
      State = [pos_row  pos_col cnt; State];
  end
  backtracking_stack = [ pos_row  pos_col; backtracking_stack]; %goal'e ulasinca dead end matrixi de check ederek daha once gecilen yerleri kaydet
  %eger `dead_end=1`se burayi 
  history_stack(pos_row, pos_col) = 1;%%eger bu row ilerlediyse history'e at daha sonra check et 
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%%%%%%%%%%%%%  hedefe olan uzakligi kontrol et%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
 dist_to_goal = sqrt(((posx) -goal_pos(1))^2 + (posy  - goal_pos(2))^2);
  if(dist_to_goal <60)
      fprintf('search path found: row%d col:%d', pos_row, pos_col);
      break;
  end
end%while
% %%%%%%%%%%%%%%%Partial Plan i dondur: previous method ile%%%%%%%%%%%%%%%%%%
goalx = ceil(goal_pos(1)/120);
goaly = ceil(goal_pos(2)/120);
goal = goalx*goaly;
curs = goal;
Partial_Plan = [goaly goalx; Partial_Plan];
while curs ~= 1
    temp_curs = previous(curs);
    if mod(temp_curs,maze_size) == 0
       pre_row = maze_size;
    else
       pre_row = mod(temp_curs,maze_size);
    end%if
    pre_col = ceil(temp_curs/maze_size);
    Partial_Plan = [pre_row pre_col; Partial_Plan];
    curs = temp_curs;
end

function R = backup(ref,mov_err,spd)
if mov_err>spd*0.8
   % back up
   kSetEncoders(ref,0,0);
   kMoveTo(ref,-100,-500);
%   kiks_pause(1);
   status=kGetStatus(ref);
   while(status(1)+status(2)<2)
      status=kGetStatus(ref);
   end;
end;
% %%%%%%%%%%%%%%%Partial Plan i dondur: eski yol%%%%%%%%%%%%%%%%%%
% total_path = size(backtracking_stack,1);
% for(i = 1:total_path)
%         row =  backtracking_stack(i);
%         col =  backtracking_stack(total_path + i);
%         %%%%bactracking_stack(1,:) = [];%%stackten cikardigin state'i sil..yani en tepedekini
%         if(dead_end(row,col)~=1)
%             Partial_Plan = [row col ; Partial_Plan];
%         end         
% end






%end A* function

% function out = calcspd(weightsL, weightsR, reflex)
% mL = weightsL(1);
% mR = weightsR(1);
%   for i=2:9
%     mL = weightsL(i)*(1/1023)*reflex(i-1)+mL;
%     mR = weightsR(i)*(1/1023)*reflex(i-1)+mR;
%  end
% out = [round(mL) round(mR)];
% 
% 
% function R = backup(ref,mov_err,spd)
% if mov_err>spd*0.8
%    % back up
%    kSetEncoders(ref,0,0);
%    kMoveTo(ref,-100,-500);
% %   kiks_pause(1);
%    status=kGetStatus(ref);
%    while(status(1)+status(2)<2)
%       status=kGetStatus(ref);
%    end;
% end;
% 
% function R = go_east(posy, posx, a)
% i = 0;
% 
% while (posx + 75) < a(2)|| (b ~= 0)
%     posx = posx + i*75
%     search_area = a(posy:posy+75; posx: posx + 75);
%     b = sum(sum(search_area));%%find if there is obstacle
%     i = i+1;
% end
% R = [posy, posx, b];%return final position and return b if there is obstacle
% end;
% 
% function R = go_west(posy, posx, a)
% i = 0;
% 
% while (posx - 75) < a(2)|| (b ~= 0)
%     posx = posx - i*75
%     search_area = a(posy:posy+75; posx - 75: posx);
%     b = sum(sum(search_area));%%find if there is obstacle
%     i = i+1;
% end
% R = [posy, posx, b];%return final position and return b if there is obstacle
% end;
% 
% function R = go_south(posy, posx, a)
% i = 0;
% 
% while (posy + 75) < a(2)|| (b ~= 0)
%     posy = posy + i*75
%     search_area = a(posy:posy+75; posx: posx + 75);
%     b = sum(sum(search_area));%%find if there is obstacle
%     i = i+1;
% end
% R = [posy, posx, b];%return final position and return b if there is obstacle
% end;
% 
% function R = go_north(posy, posx, a)
% i = 0;
% 
% while (posy - 75) < a(2)|| (b ~= 0)
%     posy = posy - i*75
%     search_area = a(posy - 75:posy; posx: posx + 75);
%     b = sum(sum(search_area));%%find if there is obstacle
%     i = i+1;
% end
% R = [posy, posx, b];%return final position and return b if there is obstacle
% end;