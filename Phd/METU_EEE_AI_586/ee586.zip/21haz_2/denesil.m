function z=denesil(A);
%BADDET  Computation of determinant by expansion along first row
%(by minors).  This is an example of a recursive Matlab function.
%Example:
%>> A=rand(7,7); det(A), tic, baddet(A), toc
%is o.k. but (WARNING)
%>> A=rand(10,10); det(A), tic, baddet(A), toc
%crashes my Matlab.
if(A~=1)
    z= A*denesil(A-1)
else z=1;
end

