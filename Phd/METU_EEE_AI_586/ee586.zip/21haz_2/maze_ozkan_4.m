% -----------------------------------------------------
%  �zkan G�NDER
%  EE586-2005  Term Project
%  Instructor: Afsar Saranli
%V.3-> ilerleme blok boyutunu 75 den 110 ya da 120 ye cikardim...
% -----------------------------------------------------
%%%Notlar: engelle kars�las�nca state geri donulebilir..tekrar search 
%%%yap�labilir 
function maze(port,baud,maze_size)
global KIKS_ARENA_EDITING_MODE KIKS_WALL_RENDER KIKS_ARENA_EDITING_OBJECTNO KIKS_ARENA_EDITING_STATE KIKS_2D_GRID KIKS_2D_GRID_OLD KIKS_GUI_HDL KIKS_GUI_ENABLED KIKS_ARENA_EDITING KIKS_BALLARRAY KIKS_LIGHTARRAY KIKS_RBTARRAY KIKS_MMPERPIXEL KIKS_ARENA_MASK_ORIG KIKS_ARENA_COLORMASK_ORIG KIKS_MMPERPIXEL_OLD;


% maze(port,baud)
% port = serial port to communicate with (port<0 ==> simulated robot, port>=0 ==> real robot
% baud = baud rate
% maze_size = size of maze

if(nargin<3) maze_size=5; end;
if(nargin<2) baud=9600; end;
if(nargin<1) port=-1; end;

if port<0 % only if this is a simulated robot
    a = kiks_generate_maze(maze_size,maze_size); 
    kiks_arena(a); % set up a new arena using the kiks_generate_maze function
end;

% for i=1:2, 
%     kiks_spawn(i+1); %%1-kucuk kure 2-buyuk 3-isik
% end
%%% size of the maze matrix %%%%
[row,col] = size(a);
pos = [col,row];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% place the object randomly %%

% kiks_spawn(1,pos);

% kiks_siminfo_robotpos
% kiks_siminfo_objects
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf(' size of maze- row: %f col: %f \n',row, col);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
objects = kiks_siminfo_objects;
[obj,prop] = size(objects);
for i=1:obj
    if(objects(i,1)==0)
        goal_pos = objects(i,2:3);
    end
end

block_size = 120;%%maze icinde search edecek block boyutu..
search_area =  a(1:block_size,1:block_size);
pos = [75-33; 75-33];
offset = 60;

kiks_arena_edit;
fprintf(' kiks arena size : row:%d col:%d',size(KIKS_ARENA_MASK_ORIG));


[row col] = size(KIKS_ARENA_MASK_ORIG);
pos = [col,row];
% kiks_spawn(1,pos);
% 
pause;
kiks_siminfo_setrobot( 55.0000,   60.0000,    6.2832);%set robot tostart pos..
%  for i=1:2, 
%      kiks_spawn(i+1); %%1-kucuk kure 2-buyuk 3-isik
%  end
% pause;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%                      Start_A* Search                            %%%%%%%%%%%%%%%%
% Partial_Plan = A_StarSearch(a, row, col, block_size, maze_size);
Partial_Plan = A_StarSearch_4(KIKS_ARENA_MASK_ORIG, row, col, block_size, maze_size)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%                         Draw Path                                %%%%%%%%%%%%%%%
temp_plan = Partial_Plan;
[temp_plan_size_row, temp_plan_size_col] = size(temp_plan);
kiks_siminfo_setrobot( 55.0000,   60.0000,    6.2832);%set robot tostart pos..
for i=1:temp_plan_size_row
    [temp_plan_size_row, temp_plan_size_col] = size(temp_plan);
    pos_row = temp_plan(1);
    pos_col = temp_plan(temp_plan_size_row + 1);
    temp_plan(1,:) = [];%%stackten cikardigin state'i sil..yani en tepedekini
    % robotun maze icinde olmasi gereken gercek pozisyonu: posy&posx
    posy = (pos_row-1) * block_size + offset;
    posx = ((pos_col-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60
    %kiks_siminfo_setrobot(posx ,posy);
    %%%%%%%%%%partial plan i ciz:%%%%%%%%%%%%%%%%%%%
    [temp_plan_size_row, temp_plan_size_col] = size(temp_plan);
    if temp_plan_size_row ~=0
        [temp_plan_size_row, temp_plan_size_col] = size(temp_plan);
        temp_row = temp_plan(1);
        temp_col = temp_plan(temp_plan_size_row + 1);
        tempy = (temp_row-1) * block_size + offset;
        tempx = ((temp_col-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60
        %%stackten cikardigin state'i sili sonraki stepte kullanilcak..
        %   
        %     fprintf(' posx: %f posy: %f  tempx: %f tempy: %f \n',posx, posy,  tempx ,tempy);
        if(tempx>=posx) & (tempy>=posy)
            plot( posx/2: tempx/2, posy/2:tempy/2,sprintf('%s.-','c'));
        elseif (tempx>=posx) & (posy>=tempy)
            plot( posx/2: tempx/2, tempy/2:posy/2,sprintf('%s.-','c'));
        elseif (tempx<=posx) & (posy>=tempy)
            plot(tempx/2:posx/2, tempy/2:posy/2,sprintf('%s.-','c'));
        elseif (tempx<=posx) & (tempy>=posy)
            plot(tempx/2:posx/2, posy/2:temp/2,sprintf('%s.-','c'));
        end%if
    end%if
end%for
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%                      Start Robot Motion                          %%%%%%%%%%%%%%%
ref=kiks_kopen([-1,baud,1]);
temp_plan = Partial_Plan;
temp_plan(1,:) = [];%%en tepedeki [1,1] oldugu icin robotun initial pozisyon die sildim
[temp_plan_size_row, temp_plan_size_col] = size(temp_plan);
kSetEncoders(ref,0,0);
for i=1:temp_plan_size_row
    [temp_plan_size_row, temp_plan_size_col] = size(temp_plan);
    temp_row = temp_plan(1);
    temp_col = temp_plan(temp_plan_size_row + 1);
    temp_plan(1,:) = [];%%stackten cikardigin state'i sil..yani en tepedekini
    tempy = (temp_row-1) * block_size + offset;
    tempx = ((temp_col-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60
    rob_pos = kiks_siminfo_robotpos;
    dist_to_target = sqrt((rob_pos(1)-tempx)^2 + (rob_pos(2) - tempy)^2);
    rob_col = ceil(rob_pos(1)/120);
    rob_row = ceil(rob_pos(2)/120);
    if(rob_col)< (temp_col)
        head = 2*pi;%pi*2
    elseif (rob_col)> (temp_col)
        head = pi;    
    elseif (rob_row)> (temp_row)
        head = pi/2;
    elseif (rob_row)< (temp_row)
        head = 3*pi/2;
    end
    %%%duvara yak�n path takip etmesini engelle...
    if rob_col == maze_size+1 
        tempx = tempx + 10;
        rob_pos(1) = rob_pos(1) + 10;
    end
    if rob_row == maze_size 
        tempy = tempy + 10;
        rob_pos(2) = rob_pos(2) + 10;
    end
    kiks_siminfo_setrobot(rob_pos(1) ,rob_pos(2),head);%%robotu gidecegi yone dogru dondur..
    
    i = 7;
    while (dist_to_target >10) | i >0% stop when robot gets near the light
        % for calculating loops/second
        ref=kiks_kopen([-1,baud,1]);
        speed = [1 1];
        %    kSetSpeed(ref,speed(1),speed(2));   
        %    mov_err = kGetStatus(ref);
        %    backup(ref,[mov_err(3) mov_err(6)],speed);
        %    kSetEncoders(ref,0,0);
        %    if head == pi | head == 2*pi
        %      x= 12 * (tempx-rob_pos(1));
        %      kMoveTo(ref, x, x);
        %    else
        %      y = 12 * (tempy-rob_pos(2));
        %      kMoveTo(ref, y, y);
        %    end
        
        %%%robotu ne kadar ilerleteceginin indexi -> i:
        if head == pi | head == 2*pi
            x = rob_pos(1) + (tempx - rob_pos(1))/i;
            i = i-1;
            y = rob_pos(2);
        else
            y = rob_pos(2) + (tempy- rob_pos(2))/i;
            i = i-1;
            x = rob_pos(1);
        end
        if x < col & y < row
            kiks_siminfo_setrobot(x ,y,head);%%robotu gidecegi yone dogru dondur..
        else
            dist_to_goal = sqrt(((posx) -goal_pos(1))^2 + (posy  - goal_pos(2))^2);
            if(dist_to_goal <60)
                fprintf('robot found goal1: row%d col:%d', pos_row, pos_col);
                break;
            end
        end
        rob_pos = kiks_siminfo_robotpos;
        dist_to_target = sqrt((rob_pos(1)-tempx)^2 + (rob_pos(2) - tempy)^2);
    end
    
    kiks_kclose(ref);%her for loop icinde bi daha kopen yap
end
end
fprintf('robot found goal2: row%d col:%d', pos_row, pos_col);


n=1;%%debug icin ..sil sonra
