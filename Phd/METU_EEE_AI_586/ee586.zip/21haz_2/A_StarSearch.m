function Partial_Plan = A_StarSearch(maze, row, col, block_size, maze_size)

objects = kiks_siminfo_objects;
[obj,prop] = size(objects);
for i=1:obj
  if(objects(i,1)==0)
    goal_pos = objects(i,2:3)
  end
end

%%manip-search yaparken maze in ortalarinda bi yerlerde cagirilacak
%%dist_to_goal = sqrt(square(pos(1)-goal_pos(1)) + square(pos(2)-goal_pos(2)));
%%en basta cagirilacak (0,0)
pos= [75-33; 75-33];
dist_to_goal = sqrt((pos(1)-goal_pos(1))^2 + (pos(2) - goal_pos(2))^2);

%%%%transform into matrix indexes%%%%%%%%
matrix_row = maze_size;
matrix_col= maze_size + 2;

moves = zeros(matrix_row,matrix_row);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%daha once gecilen yerlerden gecmemek icin kullanilacak
history_stack = zeros(matrix_row,matrix_col);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%hedefe ulastiktan sonra dead-end olan yerlerden gecmemek icin kullanilacak
%%gelinen pozisyon check edilcek eger dead-end e karsilik geliyosa orasi path e eklenmeyecek..
dead_end = zeros(matrix_row,matrix_col);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pos_col = 1;%%1-matrix_col arasinda 
pos_row= 1;%%1-matrix_row arasinda 

stack = [pos_row pos_col];
backtracking_stack = [];
Partial_Plan = [];
State = [];
offset = 60;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                  start loop                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while (dist_to_goal>50) % stop when robot gets near the light
cnt = 0;%controls if search come to dead end..loop un icinde olmali devamli update edilmeli her state icin check edilmesi icin
[stack_size_row, stack_size_col] = size(stack);
%%%%%%%%%%%%%%pop_stack: en tepedekini al%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
pos_row = stack(1);
pos_col = stack(stack_size_row + 1);
stack(1,:) = [];%%stackten cikardigin state'i sil..yani en tepedekini

% robotun maze icinde olmasi gereken gercek pozisyonu: posy&posx
posy = (pos_row-1) * block_size + offset;
posx = ((pos_col-1))* block_size + offset ;%%robotun her karenin ortasinda yer almasi icin offset=60

%%posy & posx maze dimensionlari veriyor   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                  legal moves                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%west%%
if pos_col ~= 1
   %%%%%%%%%%search_area nin matrix boyutunu geciyor mu? kontrol et--sinirlari kontrol et!!!%%%%%%%%%%%%%%%%
   trans_matrix = maze(posy, posx - block_size : posx ); %%bu matrix icinde 1 yoksa gecis yapilabilir..
   if sum(sum(trans_matrix))==0 & pos_col~=1 & history_stack(pos_row, pos_col-1)~=1%%find if there is obstacle -sum(sum(search_area))==0 
   %%%going in west direction is legal!!
   moves(pos_row,pos_col-1) = 1; 
   %%vertically concatenate the position to the stack matrix(pozisyonu en tepeye yerlestir)
   stack = [pos_row pos_col-1; stack] ;
   previous((pos_col-1-1)*maze_size + pos_row) = (pos_col-1)*maze_size + pos_row;
   cnt = cnt  + 1;
   end
end  
  %%north%%
if pos_row ~=1
   trans_matrix = maze(posy - block_size:posy , posx);
   if sum(sum(trans_matrix))==0 & pos_row~=0 & history_stack(pos_row - 1, pos_col)~=1%%find if there is obstacle -sum(sum(search_area))==0 
      %%%going in west direction is legal!!
      moves(pos_row - 1,pos_col) = 1; 
      %%vertically concatenate the position to the stack matrix(pozisyonu en tepeye yerlestir)
      stack = [ pos_row-1 pos_col; stack] ;
      previous((pos_col-1)*maze_size + pos_row-1) = (pos_col-1)*maze_size + pos_row;
      cnt = cnt  + 1;      
  end
end
  %%east%%
if pos_col ~= matrix_col
   trans_matrix = maze(posy, posx : posx + block_size);
   if sum(sum(trans_matrix))==0 & pos_col~= matrix_col & history_stack(pos_row, pos_col + 1)~=1%%find if there is obstacle -sum(sum(search_area))==0 
      %%%set going in west direction is legal if no obstacle!!
       moves(pos_row,pos_col+1)= 1; 
      %%vertically concatenate the position to the stack matrix(pozisyonu en tepeye yerlestir)
      stack = [ pos_row pos_col+1; stack] ;
      previous((pos_col+1-1)*maze_size + pos_row) = (pos_col-1)*maze_size + pos_row;
      cnt = cnt  + 1;
  end
end
  %%south%%
if pos_row ~= matrix_row

  trans_matrix = maze(posy :posy + block_size, posx: posx );
  if sum(sum(trans_matrix))==0 & matrix_row~=0 & history_stack(pos_row + 1, pos_col)~=1%%find if there is obstacle- sum(sum(search_area))==0 
      moves(pos_row + 1,pos_col) = 1;
      %%vertically concatenate the position to the stack matrix(pozisyonu en tepeye yerlestir)
      stack = [ pos_row + 1 pos_col; stack] ;
      previous((pos_col-1)*maze_size + pos_row+1) = (pos_col-1)*maze_size + pos_row;
      cnt = cnt  + 1;
  end
end

  if cnt>1%eger gidecek directionsayisi 1 den fazlaysa bu nokta bi state'dir..
      State = [pos_row  pos_col cnt; State];
  end
  backtracking_stack = [ pos_row  pos_col; backtracking_stack]; %goal'e ulasinca dead end matrixi de check ederek daha once gecilen yerleri kaydet
  %eger `dead_end=1`se burayi 
  history_stack(pos_row, pos_col) = 1;%%eger bu row ilerlediyse history'e at daha sonra check et 
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%%%%%%%%%%%%%  hedefe olan uzakligi kontrol et%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
 dist_to_goal = sqrt(((posx) -goal_pos(1))^2 + (posy  - goal_pos(2))^2);
  if(dist_to_goal <60)
      fprintf('search path found: row%d col:%d', pos_row, pos_col);
      break;
  end
end%while
% %%%%%%%%%%%%%%%Partial Plan i dondur: previous method ile%%%%%%%%%%%%%%%%%%
goalx = ceil(goal_pos(1)/120);
goaly = ceil(goal_pos(2)/120);
goal = goalx*goaly;
curs = goal;
Partial_Plan = [goaly goalx; Partial_Plan];
while curs ~= 1
    temp_curs = previous(curs);
    if mod(temp_curs,maze_size) == 0
       pre_row = maze_size;
    else
       pre_row = mod(temp_curs,maze_size);
    end%if
    pre_col = ceil(temp_curs/maze_size);
    Partial_Plan = [pre_row pre_col; Partial_Plan];
    curs = temp_curs;
end