function x=localiser
% Basic Localisation Algorithm usign EKF using Encoder and Laser
%  Juan Nieto         j.nieto@acfr.usyd.edu.au
%  Eduardo Nebot      nebot@acfr.usyd.edu.au
%  More information   http://acfr.usyd.edu.au/homepages/academic/enebot/summer_sch.htm 
%

%This algorithm does not consider the the landmarks error ( Approx 5 cm )


close all; clear all;

%Beacons Positions, taken with a kinematic GPS ( 2cm )
global beacons;
FileBEACON='beac_juan3.mat';
load(FileBEACON);
beacons=estbeac;

DeltaT=1;        
T0=0;
TF=112;     % max = 112 secs;

global GPSLon GPSLat

load('data_set');  % File with data stored according to spec provided
%-----------------------------------------------------
To=min([TimeGPS(1),Time_VS(1),TimeLaser(1)]);
TimeLaser=TimeLaser-To;
Time_VS=Time_VS-To;                 %Init time --> 0
TimeGPS=TimeGPS-To;
Time=Time-To;
%-----------------------------------------------------
[tf,If]=FINDT(TimeGPS,TF);   % to plot the gps data till TF 
GPSLon=GPSLon(1:If);
GPSLat=GPSLat(1:If);

%----------------------------------------------------------------
% Matrices to save data

global XSIZE;
global xp xest Pest ;
global innov innvar;

XSIZE=3; ZSIZE=2; USIZE=2;
num_predict=size(Time,2);
num_updates=size(TimeLaser,2)*2+ size(TimeGPS,2);

xest=zeros(XSIZE,num_predict+num_updates);
Pest=zeros(XSIZE,XSIZE,num_predict+num_updates);
innov=zeros(ZSIZE,num_updates);
innvar=zeros(ZSIZE,ZSIZE,num_updates);

%-------------On Line Plot---------------------------------------------------------

global FlagWait FlagEnd;
FlagWait = 0 ;
FlagEnd =0 ;

figure(10) ;clf ; 
hold on;
uicontrol('Style','pushbutton','String','PAUSE','Position',[10 5 50 30], 'Callback', 'fOnOff(1);');
uicontrol('Style','pushbutton','String','END  ','Position',[10 5+35 50 30], 'Callback', 'fOnOff(2);');

zoom on ;
title('EKF Localisation');xlabel('East (meters)');ylabel('North (meters)');
plot(GPSLon,GPSLat,'r.');axis([-10,20,-25,20]);
plot(beacons(:,1),beacons(:,2),'b*')
global hhh 
hhh(1)=plot(0,0,'b','erasemode','none') ;   %path estimated
hhh(2)=plot(0,0,'go','erasemode','xor') ;   %what is used in the frame
hhh(3)=plot(0,0,'b.','erasemode','xor') ;   %laser, all the frame
hhh(4)=plot(0,0,'r+','erasemode','xor') ;   %high intensity only
hhh(5)=plot(0,0,'sr','erasemode','xor') ;   %path
hhh(6)=plot(0,0,'r','erasemode','xor') ;    %lines

legend('GPS','Beacons','Path estimated','Laser Data','All laser','H. Inten.')

hold off;

%-----------------------------------------------------------------
% Filter Tuning
% These are the parameter you need to modify to improve the operation
% of the filter
%

global sigmaU sigma_laser sigma_gps;

%Internal Sensors  ( dead - reckoning )
    sigmastear=(4)*pi/180;         % Qu  10
    sigmavel=0.6;                  % Qv  0.7

%Observations:  laser Range and Bearing   ( Sick laser )
%               We are estimating the centre of a 6 cm pole
    SIGMA_RANGE=0.05;              % Rr 0.01     
    SIGMA_BEARING=(0.5)*pi/180;    % Ro 0.5 

% Observations: GPS
% This is only used at the beginning to estimate absolute heading
% and then compare the localisation results with GPS
    sigmagps=0.001;            
    
% sensors error covariance
    sigmaU=[sigmavel*sigmavel       0;
                0             sigmastear*sigmastear];
    
    sigma_laser=[SIGMA_RANGE^2     0;
                0          SIGMA_BEARING^2]  ;            
    
    sigma_gps=[sigmagps*sigmagps     0;
                0          sigmagps*sigmagps]  ;          

%--------------Initial conditions---------------------------------------------

finit=atan2(GPSLat(2)-GPSLat(1),GPSLon(2)-GPSLon(1));

xinit=[GPSLon(1);GPSLat(1);finit];

Pinit= [0.0500    0.0   0.0   ;
        0.0   0.0500    0.0   ;
        0.0   0.0    (100)*pi/180  ];

u=[Velocity(1) ; Steering(1) ];  
%-----------------------------------------------------------------------------

%-----------------------------------Running filter----------------------------    

disp('Running filter...')
global tglobal trefresh
t1=cputime;
iglobal=0;isave=1;
xp=xinit;Pp=Pinit;
j=1;tglobal=0;trefresh=0;


%********************** Navigation Loop Start ************************************

while tglobal<TF
    iglobal=iglobal+1;
    tglobal=Time(iglobal);
    if (iglobal>1)
        dt=tglobal-Time(iglobal-1);
    else
        dt=0.025;
    end
    
      %Perform a prediction with delta = previous time - actual time
    
    [xp Pp]=pred(xp,Pp,dt,u);                   % Prediction
    xest(:,isave)=xp; Pest(:,:,isave)=Pp;       % save data
    set(hhh(1),'XData',xp(1),'YData',xp(2)) ;  set(hhh(5),'XData',xp(1),'YData',xp(2)) ; %plot
    isave=isave+1;          
    
    %------------------------------------------------------------------------------------------------------------------------      
    %  GPS is sensor 1, Only used for DeltaT to evaluate initial heading !!
    if (Sensor(iglobal)==1) & (tglobal<(T0+DeltaT))                     
        zgps=[GPSLon(Index(iglobal));GPSLat(Index(iglobal))];
        [xp Pp in ins]=update_gps(xp,Pp,zgps);
        xest(:,isave)=xp; Pest(:,:,isave)=Pp;
        innov(:,j)=in; innvar(:,:,j)=ins;
        isave=isave+1;
    end 
    %-------------------------------------------------------------------------------------------------------------------------
    %Sensor =2 are Dead reckoning sensors
    if Sensor(iglobal)==2 
        u=[Velocity(Index(iglobal)) ;Steering(Index(iglobal))];              %SPEED IN m/s, stearing in rads.
    end
    %---------------------------------------------------------------------------------------------------------------------------
    % Sensor = 3 is the Laser   
    if (Sensor(iglobal)==3) & (tglobal>(T0+DeltaT))            
       [LASERr LASERo RR a]=getdata(Laser(Index(iglobal),:), Intensity(Index(iglobal),:));
       zlaser=[LASERr ; LASERo];          
       %------------------------------------------------------------------------------------------------
       laserview(RR,a,LASERr,LASERo);        %plot the laser frame
       %--------------------------------------------------------------------------------------------------
      
       %------------------------Update--------------------------------------------------------------------
       chi=5.99;
       for w=1:size(LASERr,2)    
        sum=0;
        error=0;       
        numbeacons=size(beacons,1);
        q=zeros(numbeacons,1);
        %There is no optimisation here but it is easy to understand
        %we test each beacon and perform the update, if there is more
        %than 1 hit the update is discarded. Real time code will be 
        %completelly different
        %You can improve this part and look for beacons only in an area
        
        for p=1:numbeacons
            [xe Pe in ins]=update_laser(xp,Pp,zlaser(:,w),beacons(p,:));
            q(p)=(in')*(inv(ins))*in;
            if (q(p) < chi)      
                if sum==0
                    sum=1;    
                    correct(j)=p;
                    xe1=xe;Pe1=Pe;in1=in;ins1=ins;    
                else
                    error=1;
                    correct(j)=1000;            %any value different of the number of beacons
                end
            end
        end
        if (error==0) & (sum==1)   % to verify there was only one !
           xest(:,isave)=xe1;
           Pest(:,:,isave)=Pe1;
           innov(:,j)=in1;
           innvar(:,:,j)=ins1;
           xp=xe1;Pp=Pe1;    
           set(hhh(1),'XData',xp(1),'YData',xp(2)) ;% 
           j=j+1;
           isave=isave+1;
        end
      end
  end    
  
while FlagWait,
   if FlagEnd, return  
   end  		
   pause(0.5) ;
end;
if FlagEnd, return 
end  

end

%************************ Navigation Loop End **********************************

xest=xest(:,1:isave-1);Pest=Pest(:,:,1:isave-1);innov=innov(:,1:j-1);innvar=innvar(:,:,1:j-1);
t2=cputime;
treal=TF-T0,
time=t2-t1,
taverage=(t2-t1)/iglobal,
   
disp('Filter Finished')

plots;	   
return;


%------------------------------------------------------------------------------
%      Auxiliary functions
%-------------------------------------------------------------------------------
function [xpred, Ppred]=pred(xest,Pest,dt,u);
    % Function to generate a one-step vehicle prediction .
    global sigmaU;
    global XSIZE;
    %----------------------------------------------------------------------
    %Car parameters
    L=2.83 ; h=0.76;  b = 1.21-1.42/2;  a = 3.78;   
    %-----------------------------------------------------------------------
    xpred=zeros(XSIZE,1);                           
    Ppred=zeros(XSIZE,XSIZE);

    ve=u(1);
    vc=ve/(1-tan(u(2))*h/L);  %The velocity has to be translated from the back
                              %left wheel to the center of the axle
    dvc_dve=(1-tan(u(2))*h/L)^-1;
    dvc_dalpha=ve*h/(L*(cos(u(2)))^2*(1-tan(u(2))*h/L));
    aux=(cos(u(2))^(-2));
    T1=a*sin(xest(3))+b*cos(xest(3));
    T2=a*cos(xest(3))-b*sin(xest(3));

    b1=(cos(xest(3))-tan(u(2))/L*T1)*dvc_dve;
    b3=(sin(xest(3))+tan(u(2))/L*T2)*dvc_dve;
    b5=tan(u(2))/L*dvc_dve;
    b2=-T1*vc/L*aux+b1*dvc_dalpha;
    b4=T2*vc/L*aux+b1*dvc_dalpha;
    b6=vc/L*aux+tan(u(2))/L*dvc_dalpha;

    B=dt*[ b1   b2;         %dF/dU
           b3   b4;
           b5   b6];

    xpred(1)=xest(1) + dt*vc*cos(xest(3))-dt*vc/L*tan(u(2))*(a*sin(xest(3))+b*cos(xest(3)));
    xpred(2)=xest(2) + dt*vc*sin(xest(3))+dt*vc/L*tan(u(2))*(a*cos(xest(3))-b*sin(xest(3)));         %Non lineal model
    xpred(3)=xest(3) + dt*vc/L*tan(u(2));
    xpred(3) = NormalizeAngle(xpred(3));


    % state transition matrix evaluation    (dF/dx)
    F=[1 0 -dt*(vc*sin(xest(3))+vc/L*tan(u(2))*(a*cos(xest(3))-b*sin(xest(3))))       
       0 1  dt*(vc*cos(xest(3))-vc/L*tan(u(2))*(a*sin(xest(3))+b*cos(xest(3))))       %Jacobian
       0 0                             1                          ];                   
   
    % Now compute prediction covariance
    Ppred=F*Pest*F' + B*sigmaU*B';
return;


%--------------------------------------------------------------------------------------------------------------------------------------
%Update with GPS data
function [xest, Pest, innov, S]=update_gps(xpred,Ppred,zgps)
global sigma_gps;
 
    H=[1  0  0;
       0  1  0];

    S=H*Ppred*H' + sigma_gps;           %sigma_z = R
    W=Ppred*H'* inv(S);
    Pest=Ppred-W*S*W';
    innov=[zgps-H*xpred];
  
    xest=xpred+W*innov;
return;

%--------------------------------------------------------------------------
% Function to perform the update.
function [xest, Pest, innov, S]=update_laser(xpred,Ppred,zlaser,beacons)
global sigma_laser;

    dx=beacons(1)-xpred(1);dy=beacons(2)-xpred(2);
    d=(dx^2+dy^2)^0.5;
    Jh1=-(dx)/d;
    Jh2=-(dy)/d;           %Jacobian  dH/dx
    Jh3=0;
    Jh4=(dy)/(d^2);
    Jh5=-(dx)/(d^2);
    Jh6=-1;

    Jh=[ Jh1 Jh2 Jh3;
         Jh4 Jh5 Jh6];

    H1=d;                             %h(xpred)
    H2=atan2(dy,dx)-xpred(3) + pi/2;         
    H2 = NormalizeAngle(H2);
    H=[H1 ; H2]; 
     
    S=Jh*Ppred*Jh' + sigma_laser;  
    W=Ppred*Jh'* inv(S);
    Pest=Ppred-W*S*W';
    innov=[zlaser-H];       
    innov(2) = NormalizeAngle(innov(2));
    xest=xpred+W*innov;
    xest(3) = NormalizeAngle(xest(3));
return;

%------------------------------------------------------------------------
%Function to find index in data between TO and TF
function [t,I]=FINDT(Var,ttt)
    ii=find(Var>=ttt);       
    I=ii(1);
    t=Var(I);
return;

%--------------------------------------------------------------------------  
%function for the on-line plot    
function fOnOff(x)                                      
    global FlagWait FlagEnd;
    if x==1, FlagWait=~FlagWait ; return ; end ;
    if x==2, FlagEnd=1 ; return ; end ;
return ;

%-----------------------------------------------------------------------------
%Transform GPS lat and Long to local navigation frame centred at a reference pt
function [GPSTIME,LONG,LAT] =ReadGpsData(file)
    load(file) ;                               
    LONG = GPS(:,4)' ;              
    LAT  = -GPS(:,3)' ;
    GPSTIME = GPS(:,1)'/1000 ;

    LAT0  = -33.8884;          %reference point
    LONG0 = 151.1948;

    a =  6378137.0; b  = a*(1-0.003352810664747);
    kpi = pi/180 ;
    cf = cos(LAT0*kpi) ; sf = abs(sin(LAT0*kpi)) ;
    Ro = a*a*cf/abs(sqrt(a*a*cf*cf + b*b*sf*sf))  ;
    RR = b/a  * abs(sqrt( a*a-Ro*Ro))/sf ;

    LAT =(LAT - LAT0 )*RR*kpi   ;
    LONG=(LONG- LONG0)*Ro*kpi   ;
return ;

%-----------------------------------------------------------------------------------------------------------------------------------------
function [Time,STEERING,SPEED1] = ReadUteData(file)
    load(file) ;
    STEERING = SENSORS(:,4)' ;
    SPEED1   = SENSORS(:,6)' ;
    Time     = SENSORS(:,1)'/1000 ;
return ;

%---------------------------------------------------------------------------------------------------------------------------------
%Plot the laser scan
function laserview(RR,a,LASERr,LASERo)
  
    global xp hhh;
    global isave xest tglobal trefresh;
    aa = [0:360]*pi/360 ;
    ii=find(RR<50 & RR>1) ;
    aa2=aa(ii) ; xx = RR(ii).*cos(aa2+xp(3)-pi/2) ;yy = RR(ii).*sin(aa2+xp(3)-pi/2) ;     %All points
    set(hhh(3),'XData',xx+xp(1),'YData',yy+xp(2)); 
    pause(0.01);

    ii=find(a>0) ;
    aa2=aa(ii) ; xx = RR(ii).*cos(aa2+xp(3)-pi/2) ;yy = RR(ii).*sin(aa2+xp(3)-pi/2) ; %High intensity returns
    set(hhh(4),'XData',xx+xp(1),'YData',yy+xp(2)); 
              
    ll = length(LASERr) ;
    if ll>0,
        xx = LASERr.*cos(LASERo+xp(3)-pi/2) ;               %The points we are taking from one frame
        yy = LASERr.*sin(LASERo+xp(3)-pi/2) ;
        set(hhh(2),'XData',xx+xp(1),'YData',yy+xp(2));
        
        index=[1:3:3*ll];
        xpoints=zeros(3*ll,1); ypoints=zeros(3*ll,1);           %lines between the beacons and the car
        xpoints(index)=xp(1); ypoints(index)=xp(2);
        xpoints(index+1)=xx+xp(1); ypoints(index+1)=yy+xp(2);
        xpoints(index+2)=NaN;ypoints(index+2)=NaN;
        set(hhh(6),'XData',xpoints,'YData',ypoints)
    else
        set(hhh(6),'XData',0,'YData',0)
    end ;
    if (tglobal-trefresh)>2        %every "trefresh" seconds is doing a refresh of the whole path
        set(hhh(1),'XData',xest(1,1:isave-1),'YData',xest(2,1:isave-1))
        trefresh=tglobal;    
    end
 return;


%--------------------------------------------------------------------------
%This function perform the estimation of the beacon centre, It can be improved
%There is a more general version: detectrees that works well for all cylindrical
%objects
function [LASERr,LASERo,RR,a]=getdata(laser,intensity)
    LASERr=[];                                          
    LASERo=[];
    first=0;
    max_range=30;
    angleDiff=3;
    RR=laser; a=intensity;
    for i=1:361
        if (RR(i)<max_range) & (a(i)>0)
            primera=0;
            last=[RR(i),i];
            if first==0
                init=[RR(i),i];
                first=1;
            end
        else
            if first==1
                if primera==0
                    primera=1;
                else
                    if (i-last(2))>angleDiff
                    first=0;
                    range=mean([init(1),last(1)]);
                    angle=mean([init(2),last(2)]);
                    LASERr=[LASERr range];
                    LASERo=[LASERo (angle-1)/2*pi/180]; 
                    end          
                end
            end
        end
    end
return;


%---------------------------------------------------------------------------------------------------------------------------------
%transform angles to -pi to pi
function an = NormalizeAngle(a)
    if a>pi, an =a-2*pi ;  return ; end ;
    if a<-pi, an =a+2*pi ;  return ; end ;
    an=a ;
return ; 

%---------------------------------------------------------------------------------------------------------------------------------
function Rxx=auto(x)        %This is used just for the plot

    [N,nul]=size(x'); 
    M=round(N/2);

    Xpsd=fft(x);
    Pxx=Xpsd.*conj(Xpsd)/N;

    % the inverse is the autocorrelation
    Rxx=real(ifft(Pxx));
    Rxx=Rxx(1:M);
    fact=Rxx(1); 
    for i=1:M
        Rxx(i)=Rxx(i)/fact;
    end
return

%---------------------------------------------------------------------------------------------------------------------------------
%Add what you want to plot here !!!
function plots
global xest Pest GPSLon GPSLat beacons;
global innov innvar;
    figure(1);clf
    plot(xest(1,:),xest(2,:),'c',xest(1,:),xest(2,:),'r.',GPSLon,GPSLat,'g.',beacons(:,1),beacons(:,2),'b*')
    legend('Estimated','Est. Sample','GPS','Beacons');grid on;
    xlabel('East (meters)'); ylabel('North (meters)'); title('Path')

    figure(2);clf
    plot(xest(1,:),xest(2,:),'r');grid on;
    xlabel('East (meters)'); ylabel('North (meters)');title('Estimated Path ')

    figure(3);clf
    hold on
    axis([1 size(innov,2) -0.5 0.5]);
    plot(innov(1,:)), title('X Innovations')
    plot(2*sqrt(squeeze(innvar(1,1,:))),'r')
    plot(-2*sqrt(squeeze(innvar(1,1,:))),'r')
    legend('Innovations','Std. Dev. Inn. (95%)')
    hold off

    figure(4);clf
    Rxx1=auto(innov(1,:));
    Rxx2=auto(innov(2,:));
    M=round(size(innov,2)/2);
    bounds=2*sqrt(1/(M));
    plot([1:M],Rxx1,'b',[1:M],Rxx2,'r',[1:M],bounds,'g',[1:M],-bounds,'g')
    title('Autocorrelation of Innovation Sequence')
    legend('Var. East','Var. North','95% Conf. Bounds')

    figure(5);clf
    hold on
    axis([1 size(squeeze(Pest(1,1,:)),1) 0 0.25]);
    plot(sqrt(squeeze(Pest(1,1,:))),'b')
    plot(sqrt(squeeze(Pest(2,2,:))),'r')
    plot(sqrt(squeeze(Pest(3,3,:))),'g')
    title('Covariance');legend('East var.','North var.','Steer.')
    hold off
return;
%---------------------------------------------------------------------------------------------------------------------------------
