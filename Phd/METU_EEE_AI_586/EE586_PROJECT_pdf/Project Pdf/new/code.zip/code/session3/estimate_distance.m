function [d, v] = estimate_distance (x, P),
%-------------------------------------------------------
% To be completed by the SLAM Summer School students
%-------------------------------------------------------
% function [d, v] = estimate_distance (x, P)
%
% obtain an estimated value, and variance, of the
% euclidean distance between two points, whore
% cartesian coordinates are given in x, with
% covariance given in P.
%-------------------------------------------------------

