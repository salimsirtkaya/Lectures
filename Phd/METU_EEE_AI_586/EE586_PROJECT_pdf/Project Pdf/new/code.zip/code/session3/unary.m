function ok = unary (i, j, features, observations)
%-------------------------------------------------------
% To be completed by the SLAM Summer School students
%-------------------------------------------------------
% function ok = unary (i, j, features, observations)
%
% Deterime whether observation i and feature j satisfy
% unary constraints (the trunk radii of the corresponding
% trees are stochastically compatible).
%-------------------------------------------------------
