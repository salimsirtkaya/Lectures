function ok = binary (H, i, j, features, observations)
%-------------------------------------------------------
% To be completed by the SLAM Summer School students
%-------------------------------------------------------
% function ok = binary (H, i, j, features, observations)
%
% Validate binary constrainst between pairing (Ei, Fj)
% and all pairings in H
%-------------------------------------------------------
