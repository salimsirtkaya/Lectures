package vp.mapping;


public interface LandmarkListener {
//	public void notifyLandmarkMoved(GenericLandmark lm, Point2D oldPosition);
}
