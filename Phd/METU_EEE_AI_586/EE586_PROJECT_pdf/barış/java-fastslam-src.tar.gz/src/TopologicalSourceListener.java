public interface TopologicalSourceListener {
	public void handleAction(String actionDesc);
	public void handleView(String viewDesc);
}
