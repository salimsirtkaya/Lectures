package oursland.lisp;

/**
 * @author oursland
 */
public interface LispPrintable {
	public String toLispString();
}
