package oursland;

import java.util.Random;

public class RandomSingleton {
	public static final Random	instance	= new Random(2);
}