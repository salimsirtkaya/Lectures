package oursland.text;

/**
 * @author oursland
 */
public interface KMPrintable {
	public String toKMString();
}
