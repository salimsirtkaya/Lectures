package oursland.naming;

/**
 * @author oursland
 */
public interface Namable {
	public abstract String getName();
}