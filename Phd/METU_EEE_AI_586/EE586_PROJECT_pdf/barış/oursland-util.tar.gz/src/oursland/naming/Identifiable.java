package oursland.naming;

/**
 * @author oursland
 */
public interface Identifiable {
	public int getIdentifier();
}
