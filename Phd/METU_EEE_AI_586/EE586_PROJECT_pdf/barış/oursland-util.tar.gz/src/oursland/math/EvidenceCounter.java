package oursland.math;

/**
 * @author oursland
 */
public class EvidenceCounter {
	public double support;
	public double against;
}
