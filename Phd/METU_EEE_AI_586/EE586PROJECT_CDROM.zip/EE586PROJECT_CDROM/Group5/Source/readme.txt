The source codes of fastSLAM implementation are under the \\Group5\Source\AI_EE586_fastslam.

All other files and directories under \\Group5\Source belong to KiKS simulator software.

The main body of the fastSLAM algorithm is in the m-files "\\Group5\Source\AI_EE586_fastslam\FASTSLAM.m" and "\\Group5\Source\AI_EE586_fastslam\FASTSLAM_lookup.m" for two different implementations. All other m-files are smaller code patches (functions), related to fastSLAM algorithm.