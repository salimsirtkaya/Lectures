% -----------------------------------------------------
%  (c) 2000-2004 Theodor Storm <theodor@tstorm.se>
%  http://www.tstorm.se
% -----------------------------------------------------

function kiks_recordmovie(moviename)
global KIKS_MOVIENAME
KIKS_MOVIENAME=moviename;