function PARTICLE_SET = InitParticles(no_of_particles)

% PARTICLE_SET.no_of_particles = no_of_particles;
% PARTICLE_SET.no_of_landmarks = 0;
t=1;
for i=1:no_of_particles
    PARTICLE_SET.particles(i).pose(t,1) = 0; % x position
    PARTICLE_SET.particles(i).pose(t,2) = 0; % y position
    PARTICLE_SET.particles(i).pose(t,3) = -270; % orientation
    PARTICLE_SET.particles(i).no_of_landmarks = 0;
end