function new_PARTICLE_SET = UpdateParticles(old_PARTICLE_SET)

for i=1:old_PARTICLE_SET.no_of_particles
    new_PARTICLE_SET.particles(i).pose(1) = old_PARTICLE_SET.particles(i).pose(1)+1; % x position
    new_PARTICLE_SET.particles(i).pose(2) = old_PARTICLE_SET.particles(i).pose(2)+2; ; % y position
    new_PARTICLE_SET.particles(i).pose(3) = old_PARTICLE_SET.particles(i).pose(3)+90; ; % orientation
 
end