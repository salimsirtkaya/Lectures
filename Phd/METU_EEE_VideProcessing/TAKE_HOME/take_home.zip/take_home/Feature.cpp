// Feature.cpp: implementation of the CFeature class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "VIMEK.h"
#include "Feature.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFeature::CFeature()
{

}

CFeature::~CFeature()
{

}

CBucket::CBucket()
{
	size=0;
}

CBucket::~CBucket()
{

}
